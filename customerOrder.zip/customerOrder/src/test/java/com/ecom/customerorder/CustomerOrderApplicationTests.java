package com.ecom.customerorder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerOrderApplicationTests {

	@Test
	void contextLoads() {
	}

}
